export declare const pkg = "gpt-runner-web";
