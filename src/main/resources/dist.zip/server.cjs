'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('node:http');
const server = require('./gpt-runner-web.2854bef9.cjs');
require('path');
require('tty');
require('util');
require('fs');
require('net');
require('events');
require('stream');
require('zlib');
require('buffer');
require('string_decoder');
require('querystring');
require('url');
require('http');
require('crypto');
require('os');
require('https');
require('assert');
require('tls');
require('node:child_process');
require('node:fs');
require('node:os');
require('node:path');
require('node:url');
require('child_process');
require('constants');
require('module');
require('domain');
require('stream/web');
require('worker_threads');
require('perf_hooks');
require('util/types');
require('async_hooks');
require('console');
require('diagnostics_channel');
require('vm');
require('process');
require('v8');
require('node:https');



exports.DEFAULT_CLIENT_DIST_PATH = server.DEFAULT_CLIENT_DIST_PATH;
exports.startServer = server.startServer;
