
import $__url__$ from 'url'
import $__path__$ from 'path'
const __filename = $__url__$.fileURLToPath(import.meta.url);
const __dirname = $__path__$.dirname(__filename);

          
import 'node:http';
export { D as DEFAULT_CLIENT_DIST_PATH, s as startServer } from './gpt-runner-web.5684ba1d.mjs';
import 'path';
import 'tty';
import 'util';
import 'fs';
import 'net';
import 'events';
import 'stream';
import 'zlib';
import 'buffer';
import 'string_decoder';
import 'querystring';
import 'url';
import 'http';
import 'crypto';
import 'os';
import 'https';
import 'assert';
import 'tls';
import 'node:child_process';
import 'node:fs';
import 'node:os';
import 'node:path';
import 'node:url';
import 'child_process';
import 'constants';
import 'module';
import 'domain';
import 'stream/web';
import 'worker_threads';
import 'perf_hooks';
import 'util/types';
import 'async_hooks';
import 'console';
import 'diagnostics_channel';
import 'vm';
import 'process';
import 'v8';
import 'node:https';
