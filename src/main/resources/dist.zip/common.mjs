
import $__url__$ from 'url'
import $__path__$ from 'path'
const __filename = $__url__$.fileURLToPath(import.meta.url);
const __dirname = $__path__$.dirname(__filename);

          
const pkg = "gpt-runner-web";

export { pkg };
