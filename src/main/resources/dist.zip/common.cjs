'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const pkg = "gpt-runner-web";

exports.pkg = pkg;
