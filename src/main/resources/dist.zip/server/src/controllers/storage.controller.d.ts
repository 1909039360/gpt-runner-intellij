import type { ControllerConfig } from '../types';
export declare const storageControllers: ControllerConfig;
