import type { ControllerConfig } from '../types';
export declare const gptFilesControllers: ControllerConfig;
