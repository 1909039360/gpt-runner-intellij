import type { ControllerConfig } from '../types';
export declare const llmControllers: ControllerConfig;
