import type { ControllerConfig } from '../types';
export declare const commonFilesControllers: ControllerConfig;
