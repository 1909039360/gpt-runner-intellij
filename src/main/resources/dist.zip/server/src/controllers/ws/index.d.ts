import type { WssControllerConfig } from '../../types';
export declare const allWsControllersConfig: WssControllerConfig[];
