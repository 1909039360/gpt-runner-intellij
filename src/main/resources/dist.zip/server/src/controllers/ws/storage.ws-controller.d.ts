import type { WssControllerConfig } from '../../types';
export declare const storageControllers: WssControllerConfig;
