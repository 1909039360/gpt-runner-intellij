import type { Router } from 'express';
export declare function processControllers(router: Router): void;
export declare function processWsControllers(server: any): Promise<void>;
