export declare function setProxyUrl(url?: string): Promise<void>;
